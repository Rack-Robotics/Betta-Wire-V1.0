G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,8.0.7*
G04 #@! TF.CreationDate,2025-01-17T00:22:54-07:00*
G04 #@! TF.ProjectId,toolhead-rod-energizer,746f6f6c-6865-4616-942d-726f642d656e,RevA*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 8.0.7) date 2025-01-17 00:22:54*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10RoundRect,0.585365X0.914635X0.614635X-0.914635X0.614635X-0.914635X-0.614635X0.914635X-0.614635X0*%
%ADD11O,5.000000X5.000000*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,J3*
X46000000Y-51500000D03*
X46000000Y-41500000D03*
G04 #@! TD*
G04 #@! TO.C,J2*
X46000000Y-38500000D03*
X46000000Y-28500000D03*
G04 #@! TD*
D11*
G04 #@! TO.C,J4*
X52000000Y-40000000D03*
G04 #@! TD*
G04 #@! TO.C,J1*
X40000000Y-40000000D03*
G04 #@! TD*
M02*
