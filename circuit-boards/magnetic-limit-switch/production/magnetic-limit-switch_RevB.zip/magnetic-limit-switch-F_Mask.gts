G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,8.0.7*
G04 #@! TF.CreationDate,2025-01-16T23:18:11-07:00*
G04 #@! TF.ProjectId,magnetic-limit-switch,6d61676e-6574-4696-932d-6c696d69742d,RevB*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 8.0.7) date 2025-01-16 23:18:11*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10R,1.000000X1.000000*%
%ADD11RoundRect,0.200000X0.275000X-0.200000X0.275000X0.200000X-0.275000X0.200000X-0.275000X-0.200000X0*%
%ADD12RoundRect,0.150000X0.150000X-0.512500X0.150000X0.512500X-0.150000X0.512500X-0.150000X-0.512500X0*%
%ADD13RoundRect,0.225000X-0.250000X0.225000X-0.250000X-0.225000X0.250000X-0.225000X0.250000X0.225000X0*%
%ADD14RoundRect,0.218750X0.218750X0.256250X-0.218750X0.256250X-0.218750X-0.256250X0.218750X-0.256250X0*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,TP2*
X30000000Y-26000000D03*
G04 #@! TD*
D11*
G04 #@! TO.C,R1*
X27400000Y-33325000D03*
X27400000Y-31675000D03*
G04 #@! TD*
D12*
G04 #@! TO.C,U1*
X29050000Y-31137500D03*
X30950000Y-31137500D03*
X30000000Y-28862500D03*
G04 #@! TD*
D13*
G04 #@! TO.C,C1*
X27400000Y-28625000D03*
X27400000Y-30175000D03*
G04 #@! TD*
D14*
G04 #@! TO.C,D1*
X30787500Y-33000000D03*
X29212500Y-33000000D03*
G04 #@! TD*
D10*
G04 #@! TO.C,TP3*
X28000000Y-26000000D03*
G04 #@! TD*
G04 #@! TO.C,TP1*
X32000000Y-26000000D03*
G04 #@! TD*
M02*
